﻿using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditorInternal;

public class PngWIN : EditorWindow
{
    public static Texture2D[] Arr = null;

    int W = 5;
    int X = 128;
    int Y = 128;

    public static string FileName = "";

    public bool Revers = false;

    Texture2D FlipTexture(Texture2D original)
    {

        Texture2D flipped = new Texture2D(original.width, original.height);

        int xN = original.width;
        int yN = original.height;


        for (int i = 0; i < xN; i++)
        {
            for (int j = 0; j < yN; j++)
            {
                    // flipped.SetPixel(j, xN - i - 1, original.GetPixel(j, i));
                    flipped.SetPixel(xN - i - 1, j, original.GetPixel(i, j));
            }
        }
        flipped.Apply();

        return flipped;
    }


    private void OnGUI()
    {
        if (null == Arr || 0 >= Arr.Length)
        {
            EditorGUILayout.LabelField("텍스처 선택이 안되었습니다.");
            return;
        }
        else
        {
            EditorGUILayout.LabelField("현재 선택된 텍스처 : " + Arr.Length);
        }

        W = EditorGUILayout.IntField("WCount", W);
        X = EditorGUILayout.IntField("X", X);
        Y = EditorGUILayout.IntField("Y", Y);

        if (2 >= X || 2 >= Y)
        {
            EditorGUILayout.LabelField("크기 설정이 이상합니다.");
            return;
        }

        Revers = GUILayout.Toggle(Revers, "이미지 가로로 뒤집기");

        if (true == GUILayout.Button("포폴 잘할꺼양 그죵? 하나로 만들어진 이미지"))
        {
            for (int i = 0; i < Arr.Length; i++)
            {
                string FileName = Path.GetFileName(AssetDatabase.GetAssetPath(Arr[i]));
                string Ex = Path.GetExtension(AssetDatabase.GetAssetPath(Arr[i]));
                FileName = FileName.Replace(Ex, "");

                Sprite[] AllSprite = Resources.LoadAll<Sprite>(FileName);
                // Debug.Log(FileName + AllSprite.Length);

                int H = AllSprite.Length / W;

                if (0 != AllSprite.Length % W)
                {
                    H += 1;
                }

                float TX = W * X;
                float TY = H * Y;

                Texture2D NewTexture = new Texture2D((int)TX, (int)TY, TextureFormat.ARGB32, false);

                for (int cy = 0; cy < NewTexture.height; cy++)
                {
                    for (int cx = 0; cx < NewTexture.width; cx++)
                    {
                        NewTexture.SetPixel(cx, cy, new Color(0, 0, 0, 0));
                    }
                }

                int Count = 0;
                Texture2D Tex = AllSprite[0].texture;

                if (true == Revers)
                {
                    Tex = FlipTexture(Tex);
                }

                for (int sy = H - 1; sy >= 0; --sy)
                {
                    for (int sx = 0; sx < W; ++sx)
                    {
                        if (X < AllSprite[Count].rect.width || Y < AllSprite[Count].rect.height)
                        {
                            Debug.Log(i + "무시");
                            continue;
                        }

                        if (false == Revers)
                        {
                            NewTexture.SetPixels(
                                sx * X + (X / 2) - (int)AllSprite[Count].pivot.x,
                                sy * Y + (Y / 2) - (int)AllSprite[Count].pivot.y,
                                (int)AllSprite[Count].rect.width,
                                (int)AllSprite[Count].rect.height,
                                Tex.GetPixels((int)AllSprite[Count].rect.xMin,
                                (int)AllSprite[Count].rect.yMin,
                                (int)AllSprite[Count].rect.width,
                                (int)AllSprite[Count].rect.height));
                        } else
                        {
                            // 590 x 1470
                            // 454 x 1366

                            NewTexture.SetPixels(
                                sx * X + (X / 2) - (int)AllSprite[Count].pivot.x,
                                sy * Y + (Y / 2) - (int)AllSprite[Count].pivot.y,
                                (int)AllSprite[Count].rect.width,
                                (int)AllSprite[Count].rect.height,
                                Tex.GetPixels(Tex.width - (int)AllSprite[Count].rect.width - (int)AllSprite[Count].rect.xMin,
                                (int)AllSprite[Count].rect.yMin,
                                (int)AllSprite[Count].rect.width,
                                (int)AllSprite[Count].rect.height));
                        }


                        NewTexture.Apply();

                        ++Count;
                        if (Count >= AllSprite.Length)
                        {
                            break;
                        }
                    }

                    if (Count >= AllSprite.Length)
                    {
                        break;
                    }
                }

                byte[] binData = NewTexture.EncodeToPNG();
                File.WriteAllBytes(Application.dataPath + "/PngTest/" + Arr[i].name + ".png", binData);

                // Texture2D NewTexture = new Texture2D((int)Arr[i].rect.width, (int)Arr[i].rect.height, TextureFormat.ARGB32, false);
            }

            AssetDatabase.Refresh();
        }

        FileName = GUILayout.TextField(FileName);

        if (true == GUILayout.Button("포폴 잘할꺼양 그죵? 나눠진 파일 합쳐서 저장."))
        {
            List<Sprite> AllSpriteImage = new List<Sprite>();

            for (int i = 0; i < Arr.Length; i++)
            {
                string FileName = Path.GetFileName(AssetDatabase.GetAssetPath(Arr[i]));
                string Ex = Path.GetExtension(AssetDatabase.GetAssetPath(Arr[i]));
                FileName = FileName.Replace(Ex, "");

                Sprite[] AllSprite = Resources.LoadAll<Sprite>(FileName);


                if (null != AllSprite)
                {
                    for (int z = 0; z < AllSprite.Length; z++)
                    {
                        AllSpriteImage.Add(AllSprite[z]);
                    }
                }
                else
                {
                    Sprite SSprite = Resources.Load<Sprite>(FileName);
                    if (null == SSprite)
                    {
                        AllSpriteImage.Add(SSprite);
                    }
                }
            }

            AllSpriteImage.Sort(
                delegate(Sprite A, Sprite B)
                {
                    return string.CompareOrdinal(A.name, B.name);
                }
            );

            Debug.Log(AllSpriteImage.Count);

            for (int i = 0; i < AllSpriteImage.Count; i++)
            {
                Debug.Log(AllSpriteImage[i].name);
            }

            int H = AllSpriteImage.Count / W;

            if (0 != AllSpriteImage.Count % W)
            {
                H += 1;
            }

            float TX = W * X;
            float TY = H * Y;

            Texture2D NewTexture = new Texture2D((int)TX, (int)TY, TextureFormat.ARGB32, false);

            for (int cy = 0; cy < NewTexture.height; cy++)
            {
                for (int cx = 0; cx < NewTexture.width; cx++)
                {
                    NewTexture.SetPixel(cx, cy, new Color(0, 0, 0, 0));
                }
            }

            int Count = 0;
            // Texture2D Tex = AllSpriteImage[0].texture;

            for (int sy = H - 1; sy >= 0; --sy)
            {
                for (int sx = 0; sx < W; ++sx)
                {
                    if (X < AllSpriteImage[Count].rect.width || Y < AllSpriteImage[Count].rect.height)
                    {
                        Debug.Log(AllSpriteImage[Count].name + "무시");
                        continue;
                    }

                    Texture2D Tex = AllSpriteImage[Count].texture;

                    NewTexture.SetPixels(
                        sx * X + (X / 2) - (int)AllSpriteImage[Count].pivot.x,
                        sy * Y + (Y / 2) - (int)AllSpriteImage[Count].pivot.y,
                        (int)AllSpriteImage[Count].rect.width,
                        (int)AllSpriteImage[Count].rect.height,
                        Tex.GetPixels((int)AllSpriteImage[Count].rect.xMin,
                        (int)AllSpriteImage[Count].rect.yMin,
                        (int)AllSpriteImage[Count].rect.width,
                        (int)AllSpriteImage[Count].rect.height));
                    NewTexture.Apply();

                    ++Count;
                    if (Count >= AllSpriteImage.Count)
                    {
                        break;
                    }
                }

                if (Count >= AllSpriteImage.Count)
                {
                    break;
                }
            }

            if (null == FileName || "" == FileName)
            {
                FileName = "Test";
            }

            byte[] binData = NewTexture.EncodeToPNG();
            File.WriteAllBytes(Application.dataPath + "/PngTest/" + FileName + ".png", binData);

            AssetDatabase.Refresh();
        }
    }

    private void Update()
    {
        Arr = Selection.GetFiltered<Texture2D>(SelectionMode.DeepAssets);
        Menu.TextureCheck(Arr);
        Repaint();
    }
}

public class Menu
{

    //[MenuItem("PngCutSave/FileOpen")]
    //static void PngCutSave()
    //{
    //    string ImagePath = EditorUtility.OpenFilePanel("파일을 선택해주세요", "Assets/Resources/", "");
    //    string FileName = Path.GetFileName(ImagePath);
    //    string Ex = Path.GetExtension(ImagePath);
    //    Debug.Log(FileName);
    //    Debug.Log(Ex);
    //    FileName = FileName.Replace(Ex, "");
    //    Sprite[] Arr = Resources.LoadAll<Sprite>(FileName);
    //    Debug.Log(Arr.Length);
    //    if (null == Arr || 0 == Arr.Length)
    //    {
    //        Debug.LogError("파일이 제대로 되지 않았습니다.");
    //        return;
    //    }
    //    Texture2D ParentTex = Arr[0].texture;
    //    for (int i = 0; i < Arr.Length; i++)
    //    {
    //        Debug.Log(Arr[i].rect);
    //        Texture2D NewTexture = new Texture2D((int)Arr[i].rect.width, (int)Arr[i].rect.height, TextureFormat.ARGB32, false);
    //        NewTexture.SetPixels(0, 0, (int)Arr[i].rect.width, (int)Arr[i].rect.height, ParentTex.GetPixels((int)Arr[i].rect.xMin, (int)Arr[i].rect.yMin, (int)Arr[i].rect.width, (int)Arr[i].rect.height));
    //        NewTexture.Apply();
    //        byte[] binData = NewTexture.EncodeToPNG();
    //        File.WriteAllBytes(Application.dataPath + "/PngTest/" + Arr[i].name + ".png", binData);
    //    }
    //    AssetDatabase.Refresh();
    //    // File NewFile = new File();
    //}

    public static void TextureCheck(Texture2D[] ArrTexture)
    {
        if (null == ArrTexture && 0 == ArrTexture.Length)
        {
            return;
        }

        for (int i = 0; i < ArrTexture.Length; i++)
        {
            TextureImporter TIM = (TextureImporter)AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(ArrTexture[i]));
            if (true == TIM.isReadable)
            {
                continue;
            }

            TIM.isReadable = true;
            TIM.sRGBTexture = true;
            TIM.spritePixelsPerUnit = 100f;
            TIM.textureType = TextureImporterType.Sprite;
            TIM.spriteImportMode = SpriteImportMode.Multiple;
            TIM.filterMode = FilterMode.Point;
            TIM.compressionQuality = 100;
            TIM.mipmapEnabled = false;
            TIM.maxTextureSize = 8192;
            TIM.alphaSource = TextureImporterAlphaSource.FromInput;
            TIM.alphaIsTransparency = true;
            TIM.textureCompression = TextureImporterCompression.CompressedHQ;
            TIM.wrapMode = TextureWrapMode.Clamp;
            TIM.SaveAndReimport();
        }
    }

    [MenuItem("PngCutSave/CutSave")]
    static void Test()
    {
        Texture2D[] Texture = Selection.GetFiltered<Texture2D>(SelectionMode.DeepAssets);

        if (null == Texture && 0 == Texture.Length)
        {
            Debug.Log("선택된 텍스처가 존재하지 않습니다.");
            return;
        }

        PngWIN.Arr = Texture;
        PngWIN Win = EditorWindow.GetWindow<PngWIN>();
        Win.Repaint();
        Win.Show();


        AssetDatabase.Refresh();
    }
}

